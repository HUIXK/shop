insert into t_menus (id,name,level,path) value (0,'全部',0,NULL);

insert into t_menus (id,name,level,pid) value (1,'用户管理',1,0);
insert into t_menus (id,name,level,pid) value (2,'权限管理',1,0);
insert into t_menus (id,name,level,pid) value (3,'商品管理',1,0);
insert into t_menus (id,name,level,pid) value (4,'订单管理',1,0);
insert into t_menus (id,name,level,pid) value (5,'数据统计',1,0);

insert into t_menus (id,name,level,pid,path) value (11,'用户列表',2,1,'/user_list');
insert into t_menus (id,name,level,pid,path) value (21,'角色列表',2,2,'/author_list');
insert into t_menus (id,name,level,pid,path) value (22,'权限列表',2,2,'/role_list');
insert into t_menus (id,name,level,pid,path) value (31,'商品列表',2,3,'/product_list');
insert into t_menus (id,name,level,pid,path) value (32,'分类列表',2,3,'/group_list');
insert into t_menus (id,name,level,pid,path) value (41,'订单列表',2,4,'/order_list');
insert into t_menus (id,name,level,path,pid) VALUES (51,'统计列表',2,'/data_list',5);











